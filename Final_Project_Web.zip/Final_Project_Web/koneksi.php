<?php 

  $host = "localhost";
  $username = "root";
  $password = "";
  $database = "final_pemweb";

  $koneksi = mysqli_connect($host, $username, $password, $database);

  if(!$koneksi){
  	die ("Koneksi dengan database gagal: ".mysql_connect_error());
  }

?>