<?php 
	require 'koneksi.php';
	session_start();
	$id_user = $_SESSION['id_user'];

	require 'vendor/autoload.php';
	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

	$spreadsheet = new Spreadsheet();
	$sheet = $spreadsheet->getActiveSheet();

	$sheet->setCellValue('C1', 'Laporan Keuangan');
	$sheet->setCellValue('A3', 'Nomor');
	$sheet->setCellValue('B3', 'Tanggal Transaksi');
	$sheet->setCellValue('C3', 'Deskripsi');
	$sheet->setCellValue('D3', 'Jumlah Masuk');
	$sheet->setCellValue('E3', 'Status');
	$sheet->setCellValue('F3', 'Jumlah Keluar');


	$sql = mysqli_query($koneksi,"SELECT * FROM tb_kas WHERE id_user='$id_user' ORDER BY tanggal");
	$i = 4;
	$no = 1;
	while($row = mysqli_fetch_array($sql))
	{
			$sheet->setCellValue('A'.$i, $no++);
			$sheet->setCellValue('B'.$i, $row['tanggal']);
			$sheet->setCellValue('C'.$i, $row['deskripsi']);
			$sheet->setCellValue('D'.$i, $row['jumlah']);
			$sheet->setCellValue('E'.$i, $row['status']);
			$sheet->setCellValue('F'.$i, $row['keluar']);
			$i++;
	}

	$styleArray = [
							'borders'=> [
									'allBorders'=> [
											'borderStyle'=> \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
									],
							],
					];
	$i = $i - 1;
	$sheet->getStyle('A3:F'.$i)->applyFromArray($styleArray);


	$writer = new Xlsx($spreadsheet);
	$writer->save('excel/Report Keuangan Bulanan.xlsx');
?>