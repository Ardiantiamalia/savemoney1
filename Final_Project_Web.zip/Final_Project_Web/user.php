<?php 
  require "koneksi.php";
	session_start();
	if (!isset($_SESSION['login'])) {
		echo "<script>
			alert('Dimohon Login Dahulu!');
		</script>";
		header("location:index.php?pesan=belum_login");
		exit;
	}
	if (isset($_GET['pesan'])) {
		if ($_GET['pesan'] == "gagal") {
			echo "<script>alert('Gagal Masuk! Username / Kata Sandi Salah!');</script>";
		} else if($_GET['pesan'] == "keluar") {
			echo "<script>alert('Anda Telah Berhasil Keluar!');</script>";
		} else if($_GET['pesan'] == "belum_login") {
			echo "<script>alert('Dimohon Login Terlebih dahulu!');</script>";
		} else if($_GET['pesan'] == "masuk") {
			echo "<script>alert('Selamat Datang');</script>";
		}
    exit;
	}
  
  $uname = $_SESSION['username'];
  $nama = $_SESSION['nama'];
  $email = $_SESSION['email'];
  $notelp = $_SESSION['nomor_telp'];
  

  $sql = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username='$uname'");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SAVE MONEY</title>
  <link rel="stylesheet" href="css/styleadmin.css">

  <!-- GOOGLE FONTS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
  <input type="checkbox" id="check">
  <!-- Header Start -->
  <header>
    <label for="check">
      <i class="fas fa-bars" id="sidebar_btn"></i>
    </label>
    <div class="left_area">
      <h3>SAVE MONEY</h3>
    </div>
    <div class="right_area">
    <span class="tanggal"><?php date_default_timezone_set('Asia/Jakarta'); echo date("d F Y")."&nbsp; &nbsp; &nbsp;"; ?></span>
      <a href="logout.php" class="btn_keluar">Keluar</a>
    </div>
  </header>
  <!-- Header End -->
  
  <?php foreach($sql as $row) ?>
  <!-- Sidebar Start -->
  <div class="sidebar">
    <center>
      <img src="img/<?= $row['gambar']; ?>" class="profile_img" alt="">
      <h4><?= $nama; ?></h4>
    </center>
    
    <a href="admin.php"><i class="fas fa-desktop"></i><span>Beranda</span></a>
    <a href="masuk.php"><i class="fas fa-sign-in-alt"></i><span>Pemasukan</span></a>
    <a href="keluar.php"><i class="fas fa-sign-out-alt"></i><span>Pengeluaran</span></a>
    <a href="laporan.php"><i class="fas fa-folder-open"></i><span>Laporan</span></a>
    <a href="user.php"><i class="fas fa-user"></i><span>Pengguna</span></a>
  </div>
  <!-- Sidebar End -->
  <div class="wrapper">
    <div class="inner">
      <div class="row">
        <br>
        <h2>TENTANG SAYA</h2>
        <br>
        <div class="row">
          <table style="width:50%; font-size:18px;">
            <tr>
              <td>Username</td>
              <td><?= $uname ?></td>
            </tr>
            <tr>
              <td>Nama Lengkap</td>
              <td><?= $nama ?></td>
            </tr>
            <tr>
              <td>Email</td>
              <td><?= $email; ?></td>
            </tr>
            <tr>
              <td>Nomor Telepon</td>
              <td><?= $notelp; ?></td>
            </tr>
          </table>
            <div class="modal-footer" style="margin-top:10px;">
              <a href="profile.php"><button type="submit" class="btn btn-primary">Ubah Profil</button></a>
            </div>
        </div>
      </div>
    </div>
  </div>
  
</body>
</html>