<?php 
  require "koneksi.php";
  // require 'fungsi.php';

	session_start();
	if (!isset($_SESSION['login'])) {
		echo "<script>
			alert('Dimohon Login Dahulu!');
		</script>";
		header("location:index.php?pesan=belum_login");
		exit;
	}
	if (isset($_GET['pesan'])) {
		if ($_GET['pesan'] == "gagal") {
			echo "<script>alert('Gagal Masuk! Username / Kata Sandi Salah!');</script>";
		} else if($_GET['pesan'] == "keluar") {
			echo "<script>alert('Anda Telah Berhasil Keluar!');</script>";
		} else if($_GET['pesan'] == "belum_login") {
			echo "<script>alert('Dimohon Login Terlebih dahulu!');</script>";
		} else if($_GET['pesan'] == "masuk") {
			echo "<script>alert('Selamat Datang');</script>";
		}
    exit;
	}
  
  $id_user = $_SESSION['id_user'];
  $uname = $_SESSION['username'];
  $nama = $_SESSION['nama'];
  $email = $_SESSION['email'];
  $notelp = $_SESSION['nomor_telp'];

  $sql = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username='$uname'");

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SAVE MONEY</title>
  <link rel="stylesheet" href="css/styleadmin.css">

  <!-- GOOGLE FONTS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
  <input type="checkbox" id="check">
  <!-- Header Start -->
  <header>
    <label for="check">
      <i class="fas fa-bars" id="sidebar_btn"></i>
    </label>
    <div class="left_area">
      <h3>SAVE MONEY</h3>
    </div>
    <div class="right_area">
    <span class="tanggal"><?php date_default_timezone_set('Asia/Jakarta'); echo date("d F Y")."&nbsp; &nbsp; &nbsp;"; ?></span>
      <a href="logout.php" class="btn_keluar">Keluar</a>
    </div>
  </header>
  <!-- Header End -->
  <?php foreach($sql as $row) ?>
  <!-- Sidebar Start -->
  <div class="sidebar">
    <center>
      <img src="img/<?= $row['gambar']; ?>" class="profile_img" alt="">
      <h4><?= $nama; ?></h4>
    </center>
    
    <a href="admin.php"><i class="fas fa-desktop"></i><span>Beranda</span></a>
    <a href="masuk.php"><i class="fas fa-sign-in-alt"></i><span>Pemasukan</span></a>
    <a href="keluar.php"><i class="fas fa-sign-out-alt"></i><span>Pengeluaran</span></a>
    <a href="laporan.php"><i class="fas fa-folder-open"></i><span>Laporan</span></a>
    <a href="user.php"><i class="fas fa-user"></i><span>Pengguna</span></a>
  </div>
  <!-- Sidebar End -->
  <div class="wrapper">
    <div class="inner">
      <div class="row">
        <div class="panel panel-success">
          <div class="modal-header">
            <form action="" method="post" enctype="multipart/form-data">
              <h4>UBAH PROFILE</h4>
          </div>
            <div class="modal-body">
              <div class="form-group">
                <input type="hidden" name="gambarLama" value="<?= $row['gambar']; ?>">
                <label style="font-weight: bold;">Username</label>
                <input type="text" class="form-control" name="username" required>
              </div>
              <div class="form-group">
                <label style="font-weight: bold;">Nama Lengkap</label>
                <input type="text" class="form-control" name="nama" required>
              </div>
              <div class="form-group">
                <label style="font-weight: bold;">Email</label>
                <input type="email" class="form-control" name="email" required>
              </div>
              <div class="form-group">
                <label style="font-weight: bold;">Nomor Telepon</label>
                <input type="text" class="form-control" name="nomor_telp" required>
              </div>
              <div class="form-group">
                <label style="font-weight: bold;">Foto Profil</label>
                <input type="file" style="display:block;" name="gambar">
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
      </div>
    </div>
  </div>
  <?php 
    if (isset($_POST['simpan'])) {
      function upload(){

        $namaFile = $_FILES['gambar']['name'];
        $ukuranFile = $_FILES['gambar']['size'];
        $error = $_FILES['gambar']['error'];
        $tmpName = $_FILES['gambar']['tmp_name'];
        
        // cek apakah tidak ada foto yg diupload
        if ($error === 4) {
          echo "<script>
          alert('Pilih gambar terlebih dahulu');
          </script>";
          return false;
        }
        
        // cek hanya gambar yg diupload
        $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
        $ekstensiGambar = explode('.', $namaFile);
        $ekstensiGambar = strtolower(end($ekstensiGambar));
        if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
          echo "<script>
          alert('Yang anda upload bukan gambar');
          </script>";
          return false;
        }
        
        // cek jika ukuran terlalu besar
        if($ukuranFile > 2000000){
          echo "<script>
          alert('Ukuran Gambar terlalu besar');
          </script>";
          return false;
        }
        
        // lolos semua cek, gambar siap diupload
        $namaFileBaru = uniqid();
        $namaFileBaru .= '.';
        $namaFileBaru .= $ekstensiGambar;
        
        
        move_uploaded_file($tmpName, 'img/'.$namaFileBaru);
        
        return $namaFileBaru;
      }

      $username  = $_POST['username'];
      $nama = $_POST['nama']; 
      $email  = $_POST['email'];
      $nomor_telp  = $_POST['nomor_telp'];
      $gambar = $_FILES['gambar'];
      
      if($_FILES['gambar']['error'] === 4){
        $gambar = $gambarLama;
      } else {
        // upload gambar
        $gambar = upload();
      }
      
  
      $sql = "UPDATE tb_user SET
      username = '$username', nama = '$nama', email = '$email', 
      nomor_telp = '$nomor_telp', gambar = '$gambar' WHERE id_user = '$id_user'";
      
      mysqli_query($koneksi, $sql);

      if($sql) {
				echo "<script>
				alert('Data Berhasil Diubah');
        alert('Silakan Login Kembali untuk Cek Akun');
				location.replace('logout.php');
				</script>";
      }
    }
  
  
  ?>

</body>
</html>