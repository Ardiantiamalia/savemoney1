<?php 
  require "koneksi.php";
	session_start();
	if (!isset($_SESSION['login'])) {
		echo "<script>
			alert('Dimohon Login Dahulu!');
		</script>";
		header("location:index.php?pesan=belum_login");
		exit;
	}
	if (isset($_GET['pesan'])) {
		if ($_GET['pesan'] == "gagal") {
			echo "<script>alert('Gagal Masuk! Username / Kata Sandi Salah!');</script>";
		} else if($_GET['pesan'] == "keluar") {
			echo "<script>alert('Anda Telah Berhasil Keluar!');</script>";
		} else if($_GET['pesan'] == "belum_login") {
			echo "<script>alert('Dimohon Login Terlebih dahulu!');</script>";
		} else if($_GET['pesan'] == "masuk") {
			echo "<script>alert('Selamat Datang');</script>";
		}
    exit;
	}

  $id_user = $_SESSION['id_user'];
	$username = $_SESSION['username'];
  $nama = $_SESSION['nama'];

  $sql = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username='$username'");
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SAVE MONEY</title>
  <link rel="stylesheet" href="css/styleadmin.css">

  <!-- GOOGLE FONTS -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
  <input type="checkbox" id="check">
  <!-- Header Start -->
  <header>
    <label for="check">
      <i class="fas fa-bars" id="sidebar_btn"></i>
    </label>
    <div class="left_area">
      <h3>SAVE MONEY</h3>
    </div>
    <div class="right_area">
    <span class="tanggal"><?php date_default_timezone_set('Asia/Jakarta'); echo date("d F Y")."&nbsp; &nbsp; &nbsp;"; ?></span>
      <a href="logout.php" class="btn_keluar">Keluar</a>
    </div>
  </header>
  <!-- Header End -->

  <?php foreach($sql as $row) ?>
  <!-- Sidebar Start -->
  <div class="sidebar">
    <center>
      <img src="img/<?= $row['gambar']; ?>" class="profile_img" alt="">
      <h4><?= $nama; ?></h4>
    </center>
    
    <a href="admin.php"><i class="fas fa-desktop"></i><span>Beranda</span></a>
    <a href="masuk.php"><i class="fas fa-sign-in-alt"></i><span>Pemasukan</span></a>
    <a href="keluar.php"><i class="fas fa-sign-out-alt"></i><span>Pengeluaran</span></a>
    <a href="laporan.php"><i class="fas fa-folder-open"></i><span>Laporan</span></a>
    <a href="user.php"><i class="fas fa-user"></i><span>Pengguna</span></a>
  </div>
  <!-- Sidebar End -->
  <div class="wrapper">
    <div class="inner">
      <div class="row">
      <div class="panel panel-success">
        <div class="panel panel-heading">
        <span style="font-size: 20px;">Laporan Data</span>
						<a href="reportexcel.php" class="btn btn_tambah">Cetak Excel</a>
						<a href="reportpdf.php" class="btn btn_pdf">Cetak PDF</a>
        </div>
        <!-- START TABLE -->
        <table id="tb_laporan" style="width: 100%; text-transform: capitalize;">
          <thead>
            <tr>
              <th width="3%">No.</th>
              <th width="15%"> Tgl. Transaksi</th>
              <th>Deskripsi</th>
              <th width="15%">Jumlah Masuk</th>
              <th width="15%">Status</th>
              <th width="15%">Jumlah Keluar</th>
            </tr>
          </thead>
          <tbody>
          <?php 
            $total = $total_keluar = $saldo_akhir = 0;
            $no = 1;
            $sql = "SELECT * FROM tb_kas WHERE id_user='$id_user' ORDER BY tanggal";
            $result = mysqli_query($koneksi, $sql);
            foreach ($result as $data) {
          ?>
            <tr>
              <td>
                <?= $no++; ?>
              </td>
              <td>
                <?php echo date('d F Y', strtotime($data['tanggal'])); ?>
              </td>
              <td>
                <?= $data['deskripsi']; ?>
              </td>
              <td style="text-align:right;">
                <?php 
                  echo "Rp. ";
                  echo number_format($data['jumlah']).",-"; ?>
              </td>
              <td style="text-align:right;">
                <?php echo $data['status']; ?>
              </td>
              <td style="text-align:right;">
                <?php 
                  echo "Rp. ";
                  echo number_format($data['keluar']).",-"; ?>
              </td>
            </tr>
            <?php 
              $total = $total+$data['jumlah'];
              $total_keluar = $total_keluar+$data['keluar'];

              $saldo_akhir = $total - $total_keluar;
              }
            ?>
          </tbody>
          <tr>
            <td colspan="3" style="text-align: left; font-size: 17px; color: #0e9e2d;">Total Kas Masuk :</td>
						<td style="font-size: 17px; text-align: right;"><font style="color: #00c42a;"><?php echo "Rp. " . number_format($total).",-"; ?></font></td>
          </tr>
          <tr>
            <td colspan="5" style="text-align: left; font-size: 17px; color: #de230d;">Total Kas Keluar :</td>
            <td style="font-size: 17px; text-align: right;"><font style="color: #e83b27;"><?php echo "Rp. " . number_format($total_keluar).",-"; ?></font></td>
          </tr>
          <tr>
            <td colspan="4" style="text-align: left; font-size: 17px; color: red;">Saldo Akhir :</td>
            <th style="font-size: 17px; text-align: right;"><font style="color: #463eed;"><?php echo " Rp." . number_format($saldo_akhir).",-"; ?></font></th>
          </tr>
        </table>
        </div>
      </div>
    </div>
  </div>
  
</body>
</html>